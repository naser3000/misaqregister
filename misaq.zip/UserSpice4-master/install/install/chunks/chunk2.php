';
}
}else{
if($_SERVER['HTTP_HOST'] == 'localhost'){
return 
