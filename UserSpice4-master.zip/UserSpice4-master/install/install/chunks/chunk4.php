';
}
}
}
require_once env().'users/helpers/helpers.php';
// Set config
$GLOBALS['config'] = array(
'mysql'      => array(
